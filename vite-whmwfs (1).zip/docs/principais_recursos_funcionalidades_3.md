# 3. Principais Recursos e Funcionalidades

O aplicativo de pizzaria incluirá as seguintes funcionalidades principais:

## 3.1 Requisitos Funcionais

- [RF01] Cadastro de clientes.
  O sistema deve permitir que o cliente faça um cadastro com seus dados pessoais como nome completo, data de nascimento, CPF e CEP;
- [RF02] Guardar dados do cliente.
  O sistema deve salvar os dados do cliente e protegê-los;
- [RF03] Seleção e personalização de pizzas.
  O sistema deve permitir que o cliente escolha os sabores e tamanhos das pizzas;
- [RF04] Pagamento online.
  O sistema deve permitir o pagamento pelo cartão de crédito, débito, pix e dinheiro em espécie;
- [RF05]Histórico.
  O sistema deve salvar histórico de pedidos do cliente para facilitar caso ele queira pedir novamente;
- [RNF06]Tempo de resposta rápido.
  O tempo de resposta é no máximo 10 minutos em horário comercial;
- [RF07] Endereço.
  O sistema deve entregar a pizza cobrando uma taxa de entrega;
- [RF08] Rastreamento de pedidos.
  O sistema deve ter uma aba para o cliente saber se o pedido já começou a ser feito, está em andamento ou já saiu para a entrega;
- [RF09] Acesso em tempo real localização motoqueiro
  O sistema deve fornecer a localização em tempo real do entregador;
- [RF10] Avaliação e feedback do cliente.
  O sistema deve ter um espaço para críticas e sugestões do cliente.

## 3.2 Requisitos Não Funcionais

- [RNF01] Interfaces
  O sistema deve funcionar em notebooks, computadores de mesa, tablets e smartphones;
- [RNF02]Segurança dos dados do cliente.
  O sistema deve gravar somente respostas completas em sua base de dados;
- [RNF03]Interface intuitiva e amigável.
  O sistema deve ser compatível com os sistemas operacionais Windows, Mac OS, IOS, Android e Linux. -[RNF04]Salvar dados.
  O sistema deve salvar somente respostas completas na sua base de dados. -[RNF05]Acessibilidade.
  O sistema deve ter opções de acessibilidade para pessoas com baixa visão com a opção de diminuir (A-) e/ou aumentar (A+) a fonte. -[RNF06]Disponibilidade.
  O sistema deve estar acessível na maior parte do tempo, com tempo de inatividade mínimo. -[RNF07]Velocidade de Carregamento.
  Garantir que o sistema carregue rapidamente, idealmente em poucos segundos, para melhorar a experiência do usuário.

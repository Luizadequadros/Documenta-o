---
layout: home

hero:
  name: Documentação do Software
  text: Aplicativo para pizzaria
  tagline: Integrantes - Jhenyffer Gabrielly Carneiro, Júlia Formagini Girardelo, Luiza de Quadros, Nauan e Poliana dos Santos Cenci.
  actions:
    - theme: brand
      text: Get Started
      link: /principal
    - theme: alt
      text: View on GitHub
      link: https://github.com/vuejs/vitepress
---

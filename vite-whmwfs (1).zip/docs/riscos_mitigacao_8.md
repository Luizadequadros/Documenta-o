# 8. Riscos e Mitigação

Principais riscos:

- Problemas técnicos durante o desenvolvimento.
- Baixa adoção do aplicativo por parte dos clientes.
- Concorrência no mercado de entrega de pizza online.

Estratégias de mitigação:

- Realizar testes rigorosos durante o desenvolvimento.
- Investir em marketing para promover o aplicativo.
- Monitorar a concorrência e adaptar o aplicativo conforme necessário.

# 2. Descrição do Projeto

## 2.1 Visão Geral do Projeto

O projeto Aplicativo para Pizzaria visa criar um aplicativo móvel que permitirá aos clientes fazerem pedidos de pizzas de forma conveniente e eficiente, além de poderem fretar o espaço da pizzaria para eventos como aniversários e casamentos. O aplicativo fornecerá uma variedade de funcionalidades para tornar a experiência do cliente mais agradável e ágil, dentre elas sistema de pontuação ao comprar pizzas, podendo receber pizzas grátis após acumular uma determinada quantidade, promoções exclusivas conforme o gosto de cada pessoa e uma interface simples e dinâmica para todos poderem utilizar .

## 2.2 Stakeholders

Os principais stakeholders envolvidos no projeto são:

- Clientes: Usuários do aplicativo que fazem pedidos.
- Equipe da Pizzaria: Funcionários responsáveis pelo atendimento e preparo dos pedidos.
- Investidores: Associados a pizzaria que contribuem com uma quantidade monetária para ter parte nos lucros.
- Gerentes de Projeto: Responsáveis pelo planejamento e execução do projeto.

## 2.3 Objetivos

Os principais objetivos do projeto incluem:

- Desenvolver um aplicativo de pedidos de pizza funcional e fácil de usar.
- Aumentar a conveniência para os clientes ao fazerem pedidos.
- Melhorar a eficiência das operações da pizzaria.

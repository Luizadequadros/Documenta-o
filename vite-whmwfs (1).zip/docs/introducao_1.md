# 1. Introdução

Nosso projeto é um aplicativo de uma pizzaria, no app será garantido um atendimento exclusivo para os clientes, planejamos implementar um sistema de pontuação onde quanto mais o cliente comprar mais pontos ele ganha, onde futuramente ele pode trocar esses pontos por prêmios, até mesmo pizzas grátis, também iremos fretar o local da pizzaria para eventos, por exemplo, festas de aniversário, casamentos e etc..
Nossos clientes ideais têm a partir de 18 anos, estão trabalhando, e adoram comer uma pizza com os amigos no final de semana, no nosso app eles irão poder ter isto com uma facilidade, com login facilitado via sua conta no google tudo o que ele vai precisar vai ser de um cartão de crédito ou débito.

## 1.1 Objetivo

Nosso objetivo é entregar uma pizza de qualidade, ter um aplicativo com um layout intuitivo que qualquer pessoa consiga usar com facilidade, entregar diversão e alegria junto a nossa pizza, com ótimas festas no nosso salão e atendimento exclusivo nas entregas.

## 1.2 Escopo

Este projeto visa desenvolver um aplicativo de pedidos de pizza online, que terá como finalidade permitir aos clientes fazerem pedidos de pizzas, bem como locar o local para festas e formaturas. O sistema se destina a clientes e à equipe da pizzaria.

## 1.3 Definições, Acrônimos e Abreviações

- App: Aplicativo móvel.
- Cliente: Pessoa que faz pedidos através do aplicativo.
- Pizzaria: Estabelecimento que oferece pizzas e produtos relacionados.
- Equipe: Funcionários da pizzaria responsáveis pelo preparo e entrega dos pedidos

## 1.4 Público-alvo

O público-alvo de um aplicativo de pizzaria pode ser bastante diversificado, mas geralmente inclui as seguintes categorias:
Pessoas que adoram pizza: Clientes fiéis que usem o aplicativo sempre que forem pedir uma pizza, são pessoas pagantes de todas as idades, porém normalmente tem entre 16 a 65 anos. Tem como sua dor comprar uma pizza de forma

Profissionais Ocupados: Indivíduos com agendas lotadas, como profissionais, estudantes universitários e trabalhadores, muitas vezes apreciam a conveniência de pedir pizza online ou por meio de um aplicativo, economizando tempo na preparação de refeições.

Grupos e Eventos: Grupos de amigos, colegas de trabalho ou organizadores de eventos muitas vezes fazem pedidos de pizzas para compartilhar em festas, reuniões e encontros sociais, até mesmo para locar o estabelecimento pelo app.

Clientes de Delivery: Aqueles que preferem a comodidade de receber comida em casa ou no local de trabalho frequentemente recorrem a aplicativos de pizzaria para solicitar entregas.

Clientes que Buscam Opções Personalizadas: Pessoas que desejam personalizar suas pizzas com ingredientes específicos ou optar por opções de menu especiais podem encontrar valor em aplicativos que permitem personalização.

Clientes em Busca de Variedade: Algumas pessoas buscam variedade e gostam de explorar diferentes sabores de pizza. Um aplicativo de pizzaria com um menu diversificado pode atrair esse grupo.

Os donos da Pizzaria que estarão utilizando o sistema para a gerir, desfrutando de um aplicativo onde recebem pedidos de maneira fácil e veloz.

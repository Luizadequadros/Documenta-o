## 4.1 Descrição de Caso de Uso

- Cenário: Realizar pedido
- Objetivo: Pedir uma pizza pelo sistema pela primeira vez
- Atores: Cliente
- Pré-condição: O sistema deve estar disponível on-line e o cliente deve estar logado no sistema com usuários e senha válidos.
- Fluxo de eventos:
  - Cliente: Cria sua conta utilizando sua conta no google;
  - Sistema: Os dados do cliente são guardados no banco de dados;
  - Sistema: Abre tela para fazer o pedido;
  - Cliente: Escolhe sua pizza;
  - Cliente: Informa localização para entrega;
  - Cliente: Finaliza pedido;
  - Cliente: Efetua o pagamento utilizando o cartão de crédito;
  - Sistema: Irá coletar o dinheiro;
  - Sistema: Confirma o pedido;
  - Sistema: Encaminha pedido para pizzaria;
  - Sistema: Encaminha localização do cliente para entregador;

---

## 4.1 Descrição de Caso de Uso 2.0

- Cenário: Administrador cancela pedido;;
- Objetivo: Administrador cancela um pedido que não foi pago;
- Atores: Administrador;
- Pré-condição: O sistema deve estar disponível on-line e o administrador deve estar ativo no sistema.
- Fluxo de eventos:
  - Cliente: Cria sua conta utilizando sua conta no google;
  - Sistema: Os dados do cliente são guardados no banco de dados;
  - Sistema: Abre tela para fazer o pedido;
  - Cliente: Escolhe sua pizza;
  - Cliente: Informa localização para entrega;
  - Cliente: Finaliza pedido;
  - Cliente: Não realiza pagamento nem informa que vai pagar na hora da entrega;
  - Sistema: Cancela pedido;

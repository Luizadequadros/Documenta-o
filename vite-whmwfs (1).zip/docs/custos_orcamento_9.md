# 9. Custos e Orçamento

Estimativa de custos:

- Desenvolvimento de software: R$ 5.000
- Marketing e promoção: R$ 1.600
- Manutenção e suporte: R$ 640,00
